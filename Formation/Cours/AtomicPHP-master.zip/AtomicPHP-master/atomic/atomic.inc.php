<?php

namespace Atomic;

/*
 *	Created for AtomicPHP Framework
 *	Copyright 2011 Shane Perreault All Rights Reserved
 */

require_once __DIR__ . "/Config/Config.php";
require_once __DIR__ . "/Autoloader/Autoloader.php";

use Atomic\Autoloader\Autoloader;

Autoloader::autoloadRegister();