<?php

namespace Atomic\Logging\Exceptions;

/*
 *	Created for AtomicPHP Framework
 *	Copyright 2011 Shane Perreault All Rights Reserved
 */
 
use Exception;

class LogFileNotWriteableException extends Exception {

}