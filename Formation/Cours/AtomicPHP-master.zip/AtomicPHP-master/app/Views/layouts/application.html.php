<!DOCTYPE html>
<html lang="en">

	<head>
	
		<title>html5 document</title>
	
	</head>
	
	<body>
	
		%{{YIELD}}%
	
	</body>

</html>