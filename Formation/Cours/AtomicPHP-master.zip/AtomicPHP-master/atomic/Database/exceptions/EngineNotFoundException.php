<?php

namespace Atomic\Database\Exceptions;

/*
 *	Created for AtomicPHP Framework
 *	Copyright 2011 Shane Perreault All Rights Reserved
 */
 
use Exception;

class EngineNotFoundException extends Exception {

}