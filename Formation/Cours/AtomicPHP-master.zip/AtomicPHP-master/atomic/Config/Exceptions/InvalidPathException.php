<?php

namespace Atomic\Config\Exceptions;

/*
 *	Created for AtomicPHP Framework
 *	Copyright 2011 Shane Perreault All Rights Reserved
 */
 
use Exception;

class InvalidPathException extends Exception {

}